"""
Test Module - Unit tests for CLV Predictor
"""