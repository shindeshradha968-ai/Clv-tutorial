# 💰 CLV Predictor - Customer Lifetime Value Prediction

A comprehensive machine learning application for predicting Customer Lifetime Value (CLV) using Linear Regression, Random Forest, and XGBoost algorithms.

## 📋 Table of Contents

- [Overview](#overview)
- [Features](#features)
- [Installation](#installation)
- [Usage](#usage)
- [Project Structure](#project-structure)
- [Data Requirements](#data-requirements)
- [Models](#models)
- [API Reference](#api-reference)
- [Testing](#testing)
- [Contributing](#contributing)
- [License](#license)

## 🎯 Overview

CLV Predictor is a full-stack machine learning application that helps businesses:
- Predict the lifetime value of their customers
- Segment customers based on their predicted value
- Generate actionable insights for marketing and retention strategies

## ✨ Features

- **Data Processing**: Automated data cleaning and preprocessing
- **Feature Engineering**: RFM analysis, behavioral features, and time-based features
- **Multiple ML Models**: Linear Regression, Random Forest, and XGBoost
- **Model Evaluation**: Comprehensive metrics and visualizations
- **Interactive UI**: Streamlit-based web application
- **Customer Segmentation**: Automatic segment assignment with recommendations
- **Export Capabilities**: Download predictions and models

## 🚀 Installation

### Prerequisites

- Python 3.8 or higher
- pip package manager

### Setup

1. Clone the repository:
```bash
git clone https://github.com/yourusername/clv_predictor.git
cd clv_predictor